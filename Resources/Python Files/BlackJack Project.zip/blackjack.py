from p1_random import P1Random

rng = P1Random()

game_continue = True
game_num = 0
player_wins = 0
dealer_wins = 0
tie_games = 0

while game_continue:
    #Print game #
    game_num += 1
    print(f"START GAME #{game_num}")

    #Deal first card 
    player_hand = 0
    card = rng.next_int(13) + 1

    if card == 1:
        print("Your card is a ACE!")
        card = 1
    elif 2 <= card <= 10:
        print(f"Your card is a {card}!")
        card = card
    elif card == 11:
        print("Your card is a JACK!")
        card = 10
    elif card == 12:
        print("Your card is a QUEEN!")
        card = 10
    elif card == 13:
        print("Your card is a KING!")
        card = 10

    #Add card to player hand
    player_hand += card
    print(f"Your hand is: {player_hand}")

    no_winner = True
    while no_winner:
        print("1. Get another card")
        print("2. Hold hand")
        print("3. Print statistics")
        print("4. Exit")

        option = int(input("Choose an option: "))

        #Add card to player's hand
        if option == 1:
            card = rng.next_int(13) + 1
            if card == 1:
                print("Your card is a ACE!")
                card = 1
            elif 2 <= card <= 10:
                print(f"Your card is a {card}!")
                card = card
            elif card == 11:
                print("Your card is a JACK!")
                card = 10
            elif card == 12:
                print("Your card is a QUEEN!")
                card = 10
            elif card == 13:
                print("Your card is a KING!")
                card = 10
            player_hand += card
            print(f"Your hand is: {player_hand}")
            #Add player win if win condition is met
            if player_hand == 21:
                print("BLACKJACK! You win!")
                no_winner = False
                player_wins += 1
            elif player_hand > 21:
                print("You exceeded 21! You lose.")
                no_winner = False
                dealer_wins += 1
        #Generate random value for dealer and determine win
        elif option == 2:
            dealer_hand = rng.next_int(11) + 16
            print(f"Dealer's hand: {dealer_hand}")
            print(f"Your hand  is: {player_hand}")
            if dealer_hand == 21:
                print("Dealer wins!")
                no_winner = False
                dealer_wins += 1
            elif dealer_hand > 21:
                print("You win!")
                no_winner = False
                player_wins += 1
            elif player_hand > dealer_hand:
                print("You win!")
                no_winner = False
                player_wins += 1
            elif player_hand == dealer_hand:
                print("It's a tie! No one wins!")
                no_winner = False
                tie_games += 1
            elif dealer_hand > player_hand:
                print("Dealer wins!")
                no_winner = False
                dealer_wins += 1
        #Print statistics, omit win-percent if player has none
        elif option == 3:
            print(f"Number of Player wins: {player_wins}")
            print(f"Number of Dealer wins: {dealer_wins}")
            print(f"Number of tie games: {tie_games}")
            print(f"Total # of games played is: {game_num - 1}") 
            if player_wins == 0:
                print("Percentage of Player wins: 0.0%")
            else:
                player_win_percent = float(player_wins / (game_num - 1) * 100)
                print(f"Percentage of Player wins: {player_win_percent}%")
        elif option == 4:
            no_winner = False
            game_continue = False
        else:
            print("Invalid input!")
            print("Please enter an integer value between 1 and 4.")
